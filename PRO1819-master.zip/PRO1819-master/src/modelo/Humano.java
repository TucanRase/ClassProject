package modelo;

public interface Humano {

	public int caminar(int numPasos);
	public boolean dormir (int horas);
	public float alimentarse (int calorias);
	
}
